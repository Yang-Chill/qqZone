// 0. 使用模块化机制编程，导入Vue和VueRouter，要调用 Vue.use(VueRouter)
import Vue from 'vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);
// 1. 定义 (路由) 组件。
// 可以从其他文件 import 进来
import Home from '../views/Home.vue';
// 2. 定义路由
// 每个路由应该映射一个组件。 其中"component" 可以是通过 Vue.extend() 创建的组件构造器，或者，只是一个组件配置对象。
const routes = [
    { path: '/q-zone', component: Home},
    { path: '/myzone', component: ()=> import('../views/myZone')},
    { path: '/myzone/post', component: ()=> import('../views/postZone')},
    { path: '/myphoto', component: ()=> import('../views/albumZone')},
    { path: '/myphoto/:id', component: ()=> import('../views/albumDetail')},

]
// 3. 创建 VueRouter 实例，然后传 `routes` 配置
// 你还可以传别的配置参数, 不过先这么简单着吧。
export default new VueRouter({
    mode: 'history',
    routes // (缩写) 相当于 routes: routes
})
