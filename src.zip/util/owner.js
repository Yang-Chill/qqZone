const data = {
    "nick": "晨客",
    "avatar": require('../assets/images/avatar.jpg')
};
export default {
    data
}
