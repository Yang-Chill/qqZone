export default {
        async getData(tail) {
            const api = "https://www.fastmock.site/mock/2c5613db3f13a5c02f552c9bb7e6620b/f5/api/"+tail;
            const res = await fetch(api);
            const myJson = await res.json();
            return myJson.data;
        },
        // 获取本地图片路径，用于图片src
        getUrl(file) {
            let url = null ;
            if (window.createObjectURL!=undefined) { // basic
                url = window.createObjectURL(file) ;
            }else if (window.webkitURL!=undefined) { // webkit or chrome
                url = window.webkitURL.createObjectURL(file) ;
            }else if (window.URL!=undefined) { // mozilla(firefox)
                url = window.URL.createObjectURL(file);
            }
            return url;
        }
}