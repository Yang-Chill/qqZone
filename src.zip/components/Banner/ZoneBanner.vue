<template>
    <div class="banner">
        <div class="cover">好友动态</div>
        <div class="owner">
            <img class="avatar" :src="$owner.avatar" alt="头像">
            <div class="nick">{{$owner.nick}}的空间</div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Banner"
    }
</script>

<style lang="scss" scoped>
    @import "src/style/lib";
    .banner {
        position: relative;
        width: 100%;
        height: px2rem(200);
        box-sizing: border-box;
        background: url('../../assets/images/bg.jpg') no-repeat center / cover;
        text-align: center;
        font-size: px2rem(16);
        line-height: px2rem(24);
        font-weight: 500;
        color: #fff;
        .cover {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            padding-top: px2rem(16);
            background: linear-gradient(to top,rgba(0,0,0,0.8), rgba(0,0,0,0.4));
        }
        .owner {
            z-index: 2;
            position: absolute;
            left: px2rem(30);
            bottom: px2rem(30);
            display: flex;
            align-items: center;
            .avatar {
                width: px2rem(60);
                height: px2rem(60);
                border-radius: 50%;
                margin-right: px2rem(10);
            }
            .nick {
                text-align: left;
            }
        }
    }
</style>