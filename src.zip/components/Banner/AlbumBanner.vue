<template>
    <div class="banner">
        <img class="cover" :src="album.cover">
        <div class="back" @click="$router.push('/myphoto')">
            <img src="../../assets/images/back.png" alt="返回">
        </div>
        <div class="msg">
            <div class="name">{{album.name}}</div>
            <div class="num">{{album.imgList?album.imgList.length:0}}照片</div>
            <div class="btns">
                <div class="nice" @click="$emit('showNice')">
                    <img src="../../assets/images/image 11.png">
                    <div>{{album.likedUserList?album.likedUserList.length:0}}</div>
                </div>
                <div class="comment" @click="$emit('showComment')">
                    <img src="../../assets/images/image 20.png">
                    <div>{{album.commentList?album.commentList.length:0}}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "AlbumBanner",
        props: ['album']
    }
</script>

<style lang="scss" scoped>
    @import 'src/style/lib';
    .banner {
        position: relative;
        height: px2rem(186);
        width: 100%;
        box-sizing: border-box;
    .cover {
        width: 100%;
        height: 100%;
        opacity: 0.4;
        object-fit: cover;
    }
    .back {
        position: absolute;
        height: px2rem(40);
        left: px2rem(15);
        top: 0;
        cursor: pointer;
        padding: 0;
    img {
        margin-top: px2rem(15);
        width: px2rem(11);
        height: px2rem(21);
    }
    }
    .msg {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 2;
        top: px2rem(50);
    .name {
        color: #272727;
        font-size: px2rem(24);
        line-height: px2rem(34);
        font-weight: 700;
        margin-bottom: px2rem(5);
    }
    .num {
        color: #5d5d5d;
        font-weight: 500;
        font-size: px2rem(13);
        line-height: px2rem(15);
        margin-bottom: px2rem(15);
    }
    .btns {
        display: flex;
        justify-content: space-between;
        margin: 0 auto;
        align-items: center;
        width: px2rem(235);
        height: px2rem(20);
        color: #000;
        font-size: px2rem(12);
        line-height: px2rem(17);
    div {
        display: flex;
        align-items: center;
        cursor: pointer;
    img {
        margin-right: px2rem(8);
    }
    }
    .nice img{
        width: px2rem(20);
        height: px2rem(19);
    }
    .comment img{
        width: px2rem(20);
        height: px2rem(17.35);
    }
    }
    }
    }
</style>