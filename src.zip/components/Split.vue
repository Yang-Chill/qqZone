<template>
    <div class="split"></div>
</template>

<script>
    export default {
        name: "Split"
    }
</script>

<style lang="scss" scoped>
    @import "../style/lib.scss";
    .split {
        width: 100%;
        height: px2rem(10);
        background: #F5F5F5;
    }
</style>