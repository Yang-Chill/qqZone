<!--展现views页面的统一容器-->
<template>
    <div class = "page">
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: "Page"
    }
</script>

<style lang="scss" scoped>
    @import "../style/common.scss";
    @import "../style/lib.scss";
    .page {
        position: relative;
        width: px2rem(375);
        height: px2rem(666);
        overflow: auto;
        margin: 0 auto;
        font-size: px2rem(12);
        line-height: px2rem(17);
        border-radius: px2rem(10);
        box-shadow: 12px 12px 36px 0 #cfcfcf;
        &::-webkit-scrollbar {
            width: 0;
        }
    }
</style>