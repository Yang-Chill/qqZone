<template>
    <div class="top">
        <div class="back" @click="$router.push(route)"><slot name="back"></slot></div>
        <div class="title"><slot name="title"></slot></div>
        <div class="post"><slot name="post"></slot></div>
    </div>
</template>

<script>
    export default {
        name: "ZoneHead",
        props:['route']
    }
</script>

<style lang="scss" scoped>
    @import "../style/lib.scss";
    .top {
        box-sizing: border-box;
        padding: px2rem(15) 0;
        width: 100%;
        text-align: center;
        position: relative;
        height: px2rem(50);
        font-size: px2rem(16);
        line-height: px2rem(50);
        .back {
            position: absolute;
            height: 100%;
            left: px2rem(15);
            top: 0;
            cursor: pointer;
            padding: 0;
            img {
                margin-top: px2rem(15);
                width: px2rem(11);
                height: px2rem(21);
            }
        }
        .title {
            line-height: px2rem(22);
            margin: 0 auto;
            .dec {
                color: #aaa;
                font-size: px2rem(11);
                line-height: px2rem(15);
            }
        }
        .post {
            position: absolute;
            top: px2rem(14);
            right: px2rem(12);
            box-sizing: border-box;
            padding: 0 px2rem(11);
            font-size: px2rem(14);
            line-height: px2rem(24);
            color: white;
            background: #1DAEFF;
            border-radius: px2rem(11);
            cursor: pointer;
            &:hover {
                background: rgb(209, 237, 253);
            }
        }
    }
</style>