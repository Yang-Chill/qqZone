<!--动态列表，根据接收的 tail 组合api请求数据并渲染说说列表和处理点赞评论等功能事件-->
<template>
    <div class="newsBody">
        <FriendNews :item="item" v-for="(item, index) in datas" :key="index"
                    @commited="handleCommit" @cliked="clickLiked"
                    @hideP="hidePerson" @hideN="hideNews"
        ></FriendNews>
    </div>
</template>

<script>
    import FriendNews from "@/components/FriendNews/FriendNews";
    import fetchUtil from "../../util/fetch.js";
    export default {
        name: "NewsList",
        props: ['tail'],
        components: {
            FriendNews
        },
        data: function() {
            return {
                datas:[],
            };
        },
        async mounted() {
            this.datas = await fetchUtil.getData(this.tail);
        },
        methods: {
            clickLiked(childItem) {
                console.log(childItem);
                childItem.liked = !childItem.liked;
                if (childItem.liked) {
                    childItem.content.likedList.push(this.$owner.nick);
                } else {
                    childItem.content.likedList.pop();
                }
            },
            handleCommit(childItem, comment) {
                if (childItem.content.commentList) {
                    childItem.content.commentList.push(
                        {
                            userName: this.$owner.nick,
                            txt: comment
                        }
                    );
                } else {
                    childItem.content.commentList = [{
                        userName: this.$owner.nick,
                        txt: comment
                    }];
                }
            },
            hidePerson(childItem) {
                childItem.user.invisible = true;
            },
            hideNews(childItem) {
                childItem.invisible = true;
            }
        }
    }
</script>

<style scoped>

</style>