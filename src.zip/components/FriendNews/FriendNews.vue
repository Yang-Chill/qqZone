<!--单个好友动态卡片，接收item单个动态的数据并渲染，实现点赞评论等事件的触发-->
<template>
    <div class="news" v-if="ifShowNews">
        <div class="card">
    <div class="top">
        <div class="left">
            <img class="userAvatar" :src="user.avatar">
            <div class="msg">
                <span class="nick">{{user.nick}}</span><br><span class="time">{{content.time}}</span>
            </div>
        </div>
        <div class="more" @click="more=true">
            <img src="../../assets/images/Union.png">
        </div>
    </div>
    <div class="text">{{content.txt}}</div>
    <div class="pics" v-if="imgList">
        <img v-for="(img,index) in imgList"
             :show="index<9" :style="imgStyle"
             :key="img" :src="img">
    </div>
    <div class="bottom">
        <div class="visit">浏览{{content.visitedNum}}次</div>
        <div class="btns">
            <img class="nice" @click="clickLike" :src="likeImg">
            <img class="comment" @click="$refs.input.focus()" src="../../assets/images/Group 2.png">
        </div>
    </div>
    <div class="thinkNice">
        <img src="../../assets/images/image 9.png">
        {{likedTxt}}
    </div>
    <div class="comments" v-if="item.content.commentList">
        <div class="item" v-for="(item, index) in item.content.commentList" :key="index+100">
            <div v-if="item.hasOwnProperty('feedUserName')" class="com">
                <span class="userName">{{item.userName}}</span> 回复 <span class="userName">{{item.feedUserName}} </span><span>{{item.txt}}</span>
            </div>
            <div v-else class="com">
                <span class="userName">{{item.userName}}</span><span>: {{item.txt}}</span>
            </div>
        </div>
    </div>
        <input ref="input" type="text" v-model="comment" placeholder="评论" @keyup.enter="commitFinish">
        <div class="clickMore" v-if="more">
            <div class="main">
                <img class="return" @click="leaveMore" src="../../assets/images/return.png" alt="return">
                <div class="part p1" @click="hideN">
                    <img src="../../assets/images/Group 5.png" alt="hide">
                    <div class="txt">隐藏此条动态</div>
                </div>
                <div class="line"></div>
                <div class="part p2" @click="hideP">
                    <img src="../../assets/images/image 17.png" alt="cancel">
                    <div class="txt">不看他的动态</div>
                </div>
                <div class="cancel" @click="leaveMore">取消</div>
            </div>
        </div>
    </div>
        <Split></Split>
    </div>
</template>

<script>
    import Split from "@/components/Split";
    export default {
        name: "FriendNews",
        components: {Split},
        props: ['item'],
        data() {
            return {
                content : this.item.content,
                user : this.item.user,
                imgList: this.item.content.imgList,
                commentList: this.item.content.commentList,
                video: this.item.content.video,
                comment: '',
                more: false
            };
        },
        methods : {
            clickLike() {
                this.$emit('cliked',this.item);
            },
            commitFinish() {
                this.$emit('commited', this.item, this.comment);
                this.comment = '';
            },
            leaveMore() {
                this.more=false;
            },
            hideN() {
                this.$emit('hideN', this.item);
                this.leaveMore();
            },
            hideP() {
                this.$emit('hideP', this.item);
                this.leaveMore();
            }
        },
        computed: {
            // xxx 等 n 人觉得很赞
            likedTxt() {
                const likedList = (this.item && this.content.likedList) || [];
                const len = likedList.length || 0;
                return len > 1 ? `${likedList[0]}等${len}人觉得很赞` : likedList[0];
            },
            ifShowNews() {
                return !this.item.invisible && !this.user.invisible;
            },
            likeImg() {
                return this.item.liked?require('../../assets/images/image 12.png'):require('../../assets/images/image 8.png');
            },
            imgStyle() {
                if (this.imgList){
                    const num = this.imgList.length;
                    if (num===2 ||num===4){
                        return {
                            width: `${100/2}%`,
                            height: `${35/2}%`
                        }
                    } else if (num === 1){
                        return {
                            width: `100%`,
                            height: `35%`
                        }
                    } else {
                        return {
                            width: `33%`,
                            height: `11%`
                        }
                    }
                }
                return '';
            }
        },
    }
</script>

<style lang="scss" scoped>
    @import "src/style/lib";
    .news .card{
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        padding: px2rem(15) px2rem(20);
        box-sizing: border-box;
        position: relative;
        .top{
            width: 100%;
            height: px2rem(40);
            margin-bottom: px2rem(12);
            display: flex;
            justify-content: space-between;
            .left {
                display: flex;
                .userAvatar {
                    width: px2rem(40);
                    height: px2rem(40);
                    border-radius: 50%;
                    margin-right: px2rem(9);
                }
                .msg {
                    text-align: left;
                    .nick {
                        font-size: px2rem(14);
                        line-height: px2rem(20);
                        color: #000000;
                    }
                    .time {
                        font-size: px2rem(12);
                        line-height: px2rem(20);
                        color: #737373;
                    }
                }
            }
            .more {
                width: px2rem(16);
                height: px2rem(16);
                cursor: pointer;
                img {
                    width: px2rem(16);
                    height: px2rem(4);
                }
            }
        }
        .text {
            font-size: px2rem(15);
            line-height: px2rem(21);
            text-align: left;
            color: #000;
            margin-bottom: px2rem(10);
        }
        .pics {
            display: flex;
            flex-wrap: wrap;
        }
        .bottom {
            font-size: px2rem(12);
            line-height: px2rem(17);
            color: #737373;
            width: 100%;
            height: px2rem(46);
            box-sizing: border-box;
            display: flex;
            align-items: center;
            border-bottom: px2rem(1) solid #F7F7F7;
            justify-content: space-between;
            .btns {
                height: 100%;
                display: flex;
                align-items: center;
                img {
                    width: px2rem(20);
                    height: px2rem(20);
                    cursor: pointer;
                }
                .nice {
                    margin-right: px2rem(28);
                }
            }
        }
        .thinkNice {
            text-align: left;
            color: #233268;
            margin: px2rem(8) 0;
            font-size: px2rem(14);
            line-height: px2rem(20);
            img {
                width: px2rem(16);
                height: px2rem(16);
                margin-right: px2rem(5);
            }
        }
        .comments {
            text-align: left;
            font-size: px2rem(14);
            color: #1f1f1f;
            line-height: px2rem(20);
            .item {
                margin-bottom: px2rem(8);
                .userName{
                    color: #233268;
                }
            }
        }
        input {
            width: 100%;
            height: px2rem(26);
            background: #f6f6f6;
            border-radius: 2px;
            box-sizing: border-box;
            padding: 0 px2rem(13);
            line-height: 100%;
            font-size: px2rem(14);
            color: #000000;
            opacity: 0.3;
            border: none;
            outline: none;
        }
        .clickMore {
            position: absolute;
            background: rgba(0,0,0,0.5);
            right: 0;
            left: 0;
            bottom: 0;
            top: 0;
            .main {
                position: absolute;
                background: #fff;
                right: 0;
                left: 0;
                bottom: 0;
                height: px2rem(185);
                border-top-left-radius: px2rem(10);
                border-top-right-radius: px2rem(10);
                box-sizing: border-box;
                padding: px2rem(15) px2rem(20);
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                color: #000;
                .return {
                    width: px2rem(36);
                    height: px2rem(8.4);
                    margin: 0 auto;
                    cursor: pointer;
                }
                .part {
                    display: flex;
                    align-items: center;
                    justify-content: left;
                    height: px2rem(35);
                    cursor: pointer;
                    &:hover {
                        background: #f5f7fc;
                    }
                    img {
                        height: px2rem(19);
                    }
                    .txt {
                        text-align: left;
                        font-size: px2rem(14);
                        line-height: px2rem(19);
                    }
                }
                .p1 {
                    img {
                        width: px2rem(24);
                        margin-right: 12px;
                    }
                }
                .p2 {
                    img {
                        width: px2rem(26);
                        margin-right: 10px;
                    }
                }
                .line {
                    width: px2rem(335);
                    height: px2rem(2);
                    background: #f7f7f7;
                }
                .cancel {
                    width: px2rem(335);
                    height: px2rem(40);
                    background: #E9ECF1;
                    border-radius: px2rem(2);
                    cursor: pointer;
                    text-align: center;
                    font-size: px2rem(16);
                    line-height: px2rem(40);
                    &:hover {
                        background: #E1E4e8;
                    }
                }
            }
        }
    }
</style>