<template>
    <div class="photoList" v-if="imgList?imgList.length>0:false">
        <div class="datePhotos" v-for="(photos, index) in datePhotos" :key="index+101">
            <div class="date">{{photos[0].time}}</div>
            <div class="photos">
                <img class="photo" :src="item.url" v-for="(item, index) in photos" :key="index+44">
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "PhotoList",
        props: ['imgList'],
        computed: {
            datePhotos() {
                if (this.imgList) {
                    let d=0, s=0;
                    let arr = [];
                    arr[d] = [];
                    arr[d][s] = this.imgList[0];
                    for (let i=1;i<this.imgList.length; i++) {
                        if (this.imgList[i].time === this.imgList[i-1].time){
                            s++;
                            arr[d][s] = this.imgList[i];
                        } else {
                            d++;
                            s=0;
                            arr[d] = [];
                            arr[d][s] = this.imgList[i];
                        }
                    }
                    return arr;
                }
                return [];
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import "../../style/lib.scss";
.photoList {
    width: 100%;
    box-sizing: border-box;
    padding: px2rem(30) 0 px2rem(60) px2rem(20);
    text-align: left;
    .datePhotos {
        font-weight: 500;
        font-size: px2rem(16);
        line-height: px2rem(22);
        color: #272727;
        .date {
            margin-bottom: px2rem(10);
        }
        .photos {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: px2rem(15);
            .photo {
                width: px2rem(100);
                height: px2rem(100);
                margin-right: px2rem(10);
                margin-bottom: px2rem(5);
                border-radius: px2rem(9);
                object-fit: cover;
            }
        }
    }
}
</style>