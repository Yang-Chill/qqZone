<template>
    <div class="albumsBody">
        <div class="newAlbum" @click="set=true">
            <img src="../../assets/images/image 18.png" alt="#">
            <p>新建相册</p>
        </div>
        <Album @click.native="$router.push('/myphoto/'+item.id)" :item="item" v-for="(item,index) in datas" :key="index+9"></Album>
        <DetailBox v-if="set" @off="set=false" title="新建相册">
            <div class="setBody">
                <div class="namep">
                    <div class="n">相册名字</div>
                    <input class="name" type="text" v-model="newname">
                </div>
                <div class="coverp">
                    <input id="choosec" type="file" ref="upload" @change="chooseCover" style="display: none">
                    <label class="choose" for="choosec">
                        <span>点此选择封面</span>
                        <img class="pre-cover" :src="newcover">
                    </label>
                </div>
                <div class="privatep">
                    <div class="p">设为隐私？</div>
                    <input class="private" type="checkbox" v-model="newprivate">
                </div>
                <div class="confirm" @click="setNewAlbum">确定</div>
            </div>
        </DetailBox>
    </div>
</template>

<script>
    import fetchUtil from "@/util/fetch";
    import Album from "@/components/Album/Album";
    import DetailBox from "@/components/Album/DetailBox";

    export default {
        name: "AlbumList",
        components: {Album, DetailBox},
        props : ['tail'],
        data: function() {
            return {
                datas:[],
                set: false,
                newname: '新的相册',
                newprivate: false,
                idd: 1234,
                newcover: require("../../assets/images/bg.jpg")
            };
        },
        async mounted() {
            this.datas = await fetchUtil.getData(this.tail);
            let as=0, ps=0;
            for (let i of this.datas) {
                as++;
                ps += i.imgList?i.imgList.length:0;
            }
            this.$emit('update:msg', {as, ps});
        },
        methods: {
            chooseCover() {
                const img = this.$refs.upload.files[0];
                this.newcover = fetchUtil.getUrl(img);
            },
            setNewAlbum() {
                const dd = new Date();
                const newAlbum = {
                    id: this.idd++,
                    cover: this.newcover,
                    name: this.newname,
                    private: this.newprivate,
                    likedUserList: [],
                    commentList: [],
                    imgList: [
                        {
                            url: this.newcover,
                            time: dd.getFullYear()+'/'+(dd.getMonth()+1)+'/'+dd.getMinutes()
                        }
                    ]
                };
                this.datas.push(newAlbum);
                this.newname = '新的相册';
                this.newprivate = false;
                this.newcover = require("../../assets/images/bg.jpg");
                this.set = false;
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import "src/style/lib";
.albumsBody {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: px2rem(30);
    .newAlbum {
        text-align: center;
        width: px2rem(165);
        height: px2rem(165);
        margin:px2rem(20)0 0 px2rem(15);
        border-radius: px2rem(6);
            display: flex;
            flex-direction: column;
            align-items: center;
            background: #efefef;
            font-size: px2rem(12);
            line-height: px2rem(17);
            color: #a3a3a3;
            cursor: pointer;
            img {
                margin: px2rem(51) 0 px2rem(11);
                width: px2rem(40);
                height: px2rem(32);
            }
            &:hover {
                background: #e1e1e1;
            }
        }
}
</style>