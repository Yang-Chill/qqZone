<template>
    <div class="album">
        <img :src="item.cover" alt="cover">
        <div class="name">{{item.name}}</div>
        <div class="num">{{imgNum}}张 {{item.private?'私密':''}}</div>
    </div>
</template>

<script>
    export default {
        name: "Album",
        props:['item'],
        computed : {
            imgNum() {
                return this.item.imgList.length;
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import "src/style/lib";
.album {
    display: flex;
    flex-direction: column;
    text-align: left;
    width: px2rem(165);
    margin:px2rem(20)0 0 px2rem(15);
    img {
        height: px2rem(165);
        width: 100%;
        border-radius: px2rem(6);
        margin-bottom: px2rem(10);
        object-fit: cover;
        cursor: pointer;
    }
    .name {
        color: black;
        font-size: px2rem(14);
        line-height: px2rem(20);
        font-weight: 500;
        margin-bottom: px2rem(4);
    }
    .num {
        color: #aaa;
        font-size: px2rem(12);
        line-height: px2rem(17);
    }
}
</style>