<template>
    <div class="detailBox">
        <div class="main">
            <div class="top">
                <div class="back" @click="$emit('off')">
                    <img src="../../assets/images/back.png" alt="返回">
                </div>
                <div class="title">{{title}}</div>
            </div>
            <slot></slot>
        </div>
    </div>
</template>

<script>
    export default {
        name: "DetailBox",
        props: ['title']
    }
</script>

<style lang="scss" scoped>
    @import "../../style/lib.scss";
.detailBox {
    position: fixed;
    z-index: 10;
    top:0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.2);
    .main {
        width: px2rem(350);
        height: px2rem(400);
        background: white;
        margin: px2rem(100) auto;
        box-sizing: border-box;
        padding: px2rem(5) px2rem(15);
        border-radius: px2rem(20);
        overflow: auto;
        &::-webkit-scrollbar {
            width: 0;
        }
        .top {
            box-sizing: border-box;
            padding: px2rem(15) 0;
            width: 100%;
            text-align: center;
            position: relative;
            height: px2rem(50);
            font-size: px2rem(16);
            line-height: px2rem(50);
            .back {
                position: absolute;
                height: 100%;
                left: px2rem(15);
                top: 0;
                cursor: pointer;
                padding: 0;
                img {
                    margin-top: px2rem(15);
                    width: px2rem(11);
                    height: px2rem(21);
                }
            }
            .title {
                line-height: px2rem(22);
                margin: 0 auto;
            }
        }
        .niceBody {
            width: 100%;
            font-size: px2rem(14);
            line-height: px2rem(30);
            .dec {
                display: flex;
                align-items: center;
                width: 80%;
                margin: 0 auto px2rem(20);
                justify-content: space-between;
                img {
                    width: px2rem(20);
                    height: px2rem(20);
                    cursor: pointer;
                }
            }
            .users {
                margin-left: px2rem(10);
                .user {
                    display: flex;
                    align-items: center;
                    height: px2rem(60);
                    margin-bottom: px2rem(25);
                    img {
                        width: px2rem(60);
                        height: px2rem(60);
                        border-radius: 50%;
                        margin-right: px2rem(20);
                    }
                }
            }
        }
        .commentBody {
            width: 100%;
            font-size: px2rem(14);
            line-height: px2rem(20);
            .nice {
                display: flex;
                color: #233268;
                margin:px2rem(10) px2rem(10);
                img {
                    width: px2rem(16);
                    height: px2rem(15.2);
                    margin-right: px2rem(10) ;
                }
            }
            .comments {
                .comment {
                    display: flex;
                    margin-bottom: px2rem(15);
                    img {
                        width: px2rem(50);
                        height: px2rem(50);
                        border-radius: 50%;
                    }
                    .msg {
                        text-align: left;
                        margin-left: px2rem(10);
                        .time {
                            font-size: px2rem(12);
                            color: #737373;
                        }
                    }
                }
            }
            input {
                width: 80%;
                margin: 0 auto px2rem(30);
                height: px2rem(26);
                background: #c6c6c6;
                border-radius: px2rem(5);
                box-sizing: border-box;
                padding: 0 px2rem(13);
                line-height: 100%;
                font-size: px2rem(14);
                color: #000000;
                opacity: 0.3;
                border: none;
                outline: none;
            }
        }
        .editBody {
            padding-top: px2rem(20);
            .b {
                display: block;
                margin: px2rem(30) auto;
                height: px2rem(40);
                width: px2rem(180);
                font-size: px2rem(16);
                font-weight: 500;
                line-height: px2rem(40);
                border-radius: px2rem(10);
                box-shadow: px2rem(6) px2rem(6) px2rem(12) 0 #cfcfcf;
                cursor: pointer;
                transition: 0.3s;
                &:hover {
                    transition: 0.3s;
                    box-shadow: px2rem(6) px2rem(6) px2rem(18) 0 #bfbfbf;
                }
            }
            .private span {
                transition: 0.5s;
                &.p {font-weight: 600;}
            }
        }
        .setBody {
            font-size: px2rem(16);
            .namep {
                display: flex;
                justify-content: center;
                align-items: center;
                margin: px2rem(20) 0;
                .name {
                    margin-left: px2rem(10);
                    font-size: px2rem(14);
                    color: #666;
                    border: none;
                    width: px2rem(120);
                    height: px2rem(24);
                    line-height: px2rem(24);
                    box-sizing: border-box;
                    padding: 0 px2rem(6);
                    box-shadow: inset px2rem(1) px2rem(1) px2rem(5) 0 #bfbfbf;
                    border-radius: px2rem(4);
                }
            }
            .coverp {
                font-size: px2rem(12);
                margin-bottom: px2rem(15);
                .choose {
                    display: block;
                    cursor: pointer;
                    span {
                        display: block;
                    }
                    .pre-cover {
                        width: px2rem(180);
                        height: px2rem(150);
                        object-fit: cover;
                        border-radius: px2rem(20);
                    }
                }
            }
            .privatep {
                display: flex;
                justify-content: center;
                align-items: center;
                margin-bottom: px2rem(20);
            }
            .confirm {
                cursor: pointer;
                margin: 0 auto;
                line-height: px2rem(40);
                width: px2rem(80);
                height: px2rem(40);
                border-radius: px2rem(10);
                box-shadow: px2rem(1) px2rem(1) px2rem(5) 0 #bfbfbf;
                transition: 0.2s;
                &:hover {
                    box-shadow: px2rem(1) px2rem(1) px2rem(10) 0 #cacaca;
                    transition: 0.2s;
                }
            }
        }
    }
}
</style>