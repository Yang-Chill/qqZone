<template>
    <Page>
        <ZoneHead route="/q-zone">
            <template v-slot:back>
                <img src="../assets/images/back.png" alt="返回">
            </template>
            <template v-slot:title>
                相册
                <div class="dec">{{ms.as}}相册  {{ms.ps}}照片</div>
            </template>
        </ZoneHead>
        <AlbumList tail="queryalbums" :msg.sync="ms"></AlbumList>
    </Page>
</template>

<script>
    import Page from "@/components/Page";
    import ZoneHead from "@/components/ZoneHead";
    import AlbumList from "@/components/Album/AlbumList";
    export default {
        name: "photoZone",
        components: {AlbumList, Page, ZoneHead},
        data() {
            return {
                ms : {}
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>