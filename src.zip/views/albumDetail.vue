<template>
    <Page>
        <AlbumBanner :album="album"
                    @showNice="niceP = true" @showComment="commentP = true"></AlbumBanner>
        <PhotoList class="list" :imgList="album.imgList"></PhotoList>
        <DetailBox v-if="niceP" @off="niceP=false" title="赞">
            <div class="niceBody">
                <div class="dec">
                    <div>总赞量：{{album.likedUserList.length}}</div>
                    <img :src="likeImg" @click="clickLike">
                </div>
                <div class="users">
                    <div class="user" v-for="(user,index) in album.likedUserList" :key="index+10086">
                        <img :src="user.avatar" alt="item.nick">
                        <div class="nick">{{user.nick}}</div>
                    </div>
                </div>
            </div>
        </DetailBox>
        <DetailBox v-if="commentP" @off="commentP=false" :title="album.commentList.length+'条评论'">
            <div class="commentBody">
                <div class="nice">
                    <img src="../assets/images/image 9.png" alt="#">
                    <div class="txt">{{likedTxt}}</div>
                </div>
                <div class="comments" v-if="album.commentList">
                    <div class="comment" v-for="(comment, index) in album.commentList" :key="index+201">
                        <img :src="comment.avatar" alt="#">
                        <div class="msg">
                            <div class="name">{{comment.nick}}</div>
                            <div class="time">{{comment.time?comment.time:'10:42'}}</div>
                            <div class="txt">{{comment.comment?comment.comment:'好好康！'}}</div>
                        </div>
                    </div>
                </div>
                <input type="text" v-model="myComment" @keyup.enter="handleComment" placeholder="我也评论一句...">
            </div>
        </DetailBox>
        <DetailBox v-if="edit" @off="edit=false" title="编辑">
            <div class="editBody">
                <input id="changec" type="file" ref="upload" @change="changeCover" style="display: none">
                <label class="b change" for="changec">更换封面</label>
                <div class="b private" @click="changePrivate">
                    <span>权限：</span><span class="p" :style="isP">{{album.private?'私密':'公开'}}</span>
                </div>
                <div class="b del" @click="cleanAlbum">清空相册</div>
            </div>
        </DetailBox>
        <div class="edit" @click="edit=true">
            <img src="../assets/images/image 21.png" alt="edit">
            <div>编辑相册</div>
        </div>
        <input type="file" id="add" @change="addImg" ref="addi" style="display: none" multiple>
        <label class="addB" for="add">
            <img class="add" src="../assets/images/Group 6.png" alt="add">
        </label>

    </Page>
</template>

<script>
    import Page from "@/components/Page";
    import fetchUtil from "@/util/fetch";
    import AlbumBanner from "@/components/Banner/AlbumBanner";
    import PhotoList from "@/components/Album/PhotoList";
    import DetailBox from "@/components/Album/DetailBox";
    export default {
        name: "albumDetail",
        components: {DetailBox, PhotoList, AlbumBanner, Page},
        data() {
            return {
                id: this.$route.params.id,
                album: {},
                edit: false,
                niceP: false,
                commentP: false,
                liked: false,
                myComment: '',
            }
        },
        computed : {
            likeImg() {
                return this.liked?require('../assets/images/image 12.png'):require('../assets/images/image 8.png');
            },
            likedTxt() {
                const list = this.album.likedUserList;
                const len = list?list.length:0;
                if (len===0) return '还没人赞过';
                let result='';
                for (let i=0; i<len; i++) {
                    result += list[i].nick;
                    if (i!==len-1) {
                        result += '、';
                    }
                }
                return result+'觉得很赞';
            },
            isP() {
                if (this.album.private) return {
                    color: 'red'
                }
                else return {
                    color: 'green'
                }
            }
        },
        methods : {
            clickLike() {
                this.liked = !this.liked;
                    if (this.liked) {
                        this.album.likedUserList.push(this.$owner);
                    } else {
                        this.album.likedUserList.pop();
                    }
                },
            handleComment() {
                let date = new Date();
                let d = {
                    nick: this.$owner.nick,
                    avatar: this.$owner.avatar,
                    comment: this.myComment,
                    time: date.getHours()+":"+date.getMinutes()
                }
                this.album.commentList.push(d);
                this.myComment = ''
            },
            changeCover() {
                const file = this.$refs.upload.files[0];
                // const reader = new FileReader();
                // reader.readAsDataURL(file);
                // //创建文件读取相关的变量
                // let imgFile;
                // //为文件读取成功设置事件
                // reader.onload=function(e) {
                //     // alert('文件读取完成');
                //     imgFile = e.target.result;
                //     // console.log(imgFile);
                // };
                this.album.cover = fetchUtil.getUrl(file);
            },
            changePrivate() {
                this.album.private = !this.album.private;
            },
            cleanAlbum() {
                this.album.imgList = [];
                this.edit = false;
            },
            addImg() {
                const dd = new Date();
                const files = this.$refs.addi.files;
                for (let f of files) {
                    console.log(f);
                    this.album.imgList.push( {
                        url: fetchUtil.getUrl(f),
                        time: dd.getFullYear()+'/'+(dd.getMonth()+1)+'/'+dd.getDate()
                    })
                }
            }

        },
        async mounted() {
            const data = await fetchUtil.getData('getalbum?id='+this.id);
            let album = data.album;
            if (!album.commentList) album.commentList = [];
            if (!album.likedUserList) album.likedUserList = [];
            this.album = album;
        }
    }
</script>

<style lang="scss" scoped>
    @import '../style/lib.scss';
    .edit {
        position: fixed;
        top: px2rem(623.5);
        height: px2rem(50);
        width: px2rem(375);
        margin: 0 auto;
        background: white;
        cursor: pointer;
        font-size: px2rem(11);
        border-radius: px2rem(10);
        box-shadow: px2rem(0) px2rem(2.5) px2rem(5) 0 #afafaf;
        transition: 0.3s;
        &:hover {
            transition: 0.3s;
            box-shadow: px2rem(0) px2rem(2.5) px2rem(10) 0 #afafaf;
        }
        img {
            margin-top: px2rem(5);
            width: px2rem(22);
            height: px2rem(22);
        }
    }
    .addB .add {
        position: fixed;
        top: px2rem(520);
        margin-left: px2rem(110);
        height: px2rem(50);
        width: px2rem(50);
        cursor: pointer;
        border-radius: 50%;
        box-shadow: px2rem(8) px2rem(8) px2rem(24) 0 #cfcfcf;
    }
</style>