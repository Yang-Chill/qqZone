<template>
    <Page>
        <ZoneHead route="/myzone">
            <template v-slot:back>取消</template>
            <template v-slot:title>说说</template>
            <template v-slot:post>发布</template>
        </ZoneHead>
        <Split></Split>
        <div class="post-area">
            <div class="msg">
                <img class="avatar" :src="$owner.avatar">
                {{$owner.nick}}
            </div>
            <label>
                <textarea class="content" placeholder="分享新鲜事......"></textarea>
            </label>
            <div class="pics">
                <div class="pic default">
                    <img src="../assets/images/pic.png" alt="#">
                    <p>照片/视频</p>
                </div>
            </div>
        </div>
    </Page>
</template>

<script>
    import Page from "@/components/Page";
    import Split from "@/components/Split";
    import ZoneHead from "@/components/ZoneHead";
    export default {
        name: "postZone",
        components: {ZoneHead, Split, Page}
    }
</script>

<style lang="scss" scoped>
    @import "../style/lib.scss";
    .post-area {
        box-sizing: border-box;
        padding: px2rem(15) px2rem(20);
        .msg {
            height: px2rem(40);
            display: flex;
            align-items: center;
            font-size: px2rem(16);
            line-height: px2rem(24);
            color: black;
            margin-bottom: px2rem(20);
            .avatar {
                width: px2rem(40);
                height: px2rem(40);
                border-radius: 50%;
                margin-right: px2rem(10);
            }
        }
        textarea {
            border: none;
            background: white;
            height: px2rem(120);
            width: 100%;
            color: #c9c9c9;
            font-size: px2rem(15);
            line-height: px2rem(21);
            outline: none;
        }
        .pics {
            display: flex;
            flex-wrap: wrap;
            .pic {
                width: px2rem(100);
                height: px2rem(100);
                border-radius: px2rem(2);
            }
            .default {
                display: flex;
                flex-direction: column;
                align-items: center;
                background: #efefef;
                font-size: px2rem(12);
                line-height: px2rem(17);
                text-align: center;
                color: #a3a3a3;
                cursor: pointer;
                img {
                    margin: px2rem(26) 0 px2rem(10);
                    width: px2rem(30);
                    height: px2rem(24.7);
                }
                &:hover {
                    background: #e1e1e1;
                }
            }
        }
    }
</style>