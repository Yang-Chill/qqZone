<template>
    <Page>
        <Banner></Banner>
        <div class="guide">
            <div class="g"  @click="$router.push('/myphoto')">
                <img class="icon1" src="../assets/images/image 3.png">
                <div>相册</div>
            </div>
            <div class="g" @click="$router.push('/myzone')">
                <img class="icon2" src="../assets/images/image 5.png">
                <div>说说</div>
            </div>
        </div>
        <NewsList tail="querynews"></NewsList>
    </Page>
</template>

<script>
    import Banner from "../components/Banner/ZoneBanner.vue";
    import NewsList from "@/components/FriendNews/NewsList";
    import Page from "@/components/Page";
    export default {
        name: "Home",
        components: {
            Banner,NewsList, Page
        }
    }
</script>

<style lang="scss" scoped>
    @import "../style/lib.scss";
      .guide {
          width: 100%;
          height: px2rem(65);
          border-bottom: px2rem(1) solid #f2f2f2;
          margin: 0 auto;
          box-sizing: border-box;
          padding: 0 px2rem(61);
          display: flex;
          justify-content: space-between;
          .g {
              height: 100%;
              display: flex;
              flex-direction: column;
              align-items: center;
              cursor: pointer;
              img {
                  margin-top: px2rem(10);
              }
              .icon1 {
                  height: px2rem(21);
                  margin-bottom: px2rem(10);
              }
              .icon2 {
                  height: px2rem(24.4);
                  margin-bottom: px2rem(6.8);
              }
          }
      }

</style>