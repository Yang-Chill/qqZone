<template>
    <Page>
        <ZoneHead route="/q-zone">
            <template v-slot:back>
                <img src="../assets/images/back.png" alt="返回">
            </template>
            <template v-slot:title>说说</template>
        </ZoneHead>
        <div class="post">
            <img class="avatar" :src="$owner.avatar">
            <input @click="$router.push('/myzone/post')" type="text" placeholder="分享新鲜事">
        </div>
        <Split></Split>
        <NewsList tail="querymynews"></NewsList>
    </Page>
</template>

<script>
    import NewsList from "@/components/FriendNews/NewsList";
    import Page from "@/components/Page";
    import Split from "@/components/Split";
    import ZoneHead from "@/components/ZoneHead";
    export default {
        name: "myZone",
        components: {
            ZoneHead,
            Split,
            NewsList, Page
        }
    }
</script>

<style lang="scss" scoped>
    @import "../style/lib.scss";
    .post {
        height: px2rem(70);
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-sizing: border-box;
        padding: px2rem(15) px2rem(20);
        .avatar {
            width: px2rem(40);
            height: px2rem(40);
            border-radius: 50%;
        }
        input {
            outline: none;
            border: none;
            width: px2rem(280);
            height: px2rem(40);
            border-radius: px2rem(20);
            background: #eeeeee;
            box-sizing: border-box;
            padding: px2rem(10) px2rem(18);
            text-align: left;
            color: #acacac;
            font-size: px2rem(14);
            line-height: px2rem(20);
        }
    }
</style>